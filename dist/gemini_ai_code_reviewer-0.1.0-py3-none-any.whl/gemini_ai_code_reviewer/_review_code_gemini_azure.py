import base64
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import os
import re
from typing import List, Dict, Any
import google.generativeai as Client
from pprint import pprint

import difflib
import requests
import fnmatch
from unidiff import Hunk, PatchedFile, PatchSet
import urllib

from review_code_gemini import PRDetails
from utils.gemini_analyze import analyze_code, create_review_comment
from utils.git_helper import parse_diff, EXCLUDE_PATTERN_DEFAULT

# AZURE_ORG_URL = os.getenv("AZURE_ORG_URL")
# AZURE_PROJECT = os.getenv("AZURE_PROJECT")
# AZURE_PAT = os.getenv("AZURE_PAT")
# REPO_ID = os.getenv("AZURE_REPO_ID")  # ID of repository
# PULL_REQUEST_ID = os.getenv("PULL_REQUEST_ID")  # Pull request ID


AZURE_ORG_URL = 'https://dev.azure.com/zuelligpharmadevops'
AZURE_PROJECT = 'eZRx%20Mobile'
AZURE_PAT = '7gMJwckLs0pKfjo5XqtF3PZw0IjFBdKCMNvkJfvbswjjDts508o9JQQJ99BBACAAAAAwOFKdAAASAZDO2ORB'
REPO_ID = 'eZRx%20Mobile'  # ID of repository
PULL_REQUEST_ID = '129569'  # Pull request ID
OUTPUT_FILE = "changes.diff"

# Gemini Configuration
gemini_client = Client.configure(api_key='AIzaSyDWTFP37AMLZddgsY4Hf2yjyfZOh3tyV8Y')

def get_basic_auth_string():
     """Create a Base64 encoded basic authentication string from PAT."""
     pat_bytes = f":{AZURE_PAT}".encode()
     base64_pat = base64.b64encode(pat_bytes).decode()

     return f"Basic {base64_pat}"

def _extract_branch_name(ref_name: str) -> str:
    """
    Extracts the branch name from a Git ref name string.

    Args:
        ref_name: The Git ref name string (e.g., "refs/heads/main", "refs/heads/feat/my-feature").

    Returns:
        The branch name (e.g., "main", "feat/my-feature").
        Returns an empty string if the ref name is not in the expected format.
    """
    match = re.match(r"refs/heads/(.+)", ref_name)
    if match:
        return match.group(1)
    else:
        return ""

def get_pull_request_details() -> PRDetails:
    """Get details of the pull request from Azure DevOps."""
    url = f"{AZURE_ORG_URL}/{AZURE_PROJECT}/_apis/git/repositories/{REPO_ID}/pullRequests/{PULL_REQUEST_ID}?api-version=7.1"
    headers = {
        'Authorization': f'{get_basic_auth_string()}'
    }
    try:
        response = requests.get(url, headers=headers)
        
        response.raise_for_status()
        data = response.json()  # Parse the JSON response

        owner = data.get("createdBy", {}).get("uniqueName", "Unknown Owner")  # Assuming the creator is the "owner"
        repo = data.get("repository", {}).get("name", "Unknown Repo")
        pull_number = data.get("pullRequestId", "Unknown ID")
        title = data.get("title", "No Title")
        description = data.get("description", "No Description")
        source_branch = _extract_branch_name(data.get("sourceRefName", "No source branch"))
        target_branch = _extract_branch_name(data.get("targetRefName", "No target branch"))

        return PRDetails(owner, repo, pull_number,title, description,source_branch,target_branch)
    except requests.exceptions.RequestException as e:
        return None
        
def _filter_diff_data(diff_data):
    """
    Filters the diff data to remove changes where 'isFolder' is True.

    Args:
        diff_data (dict or str): The diff data, either as a dictionary or a JSON string.

    Returns:
        dict: The filtered diff data, with 'isFolder' True changes removed.
    """
    if isinstance(diff_data, str):
        try:
            diff_data = json.loads(diff_data)
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON: {e}")
            return None
    
    if not isinstance(diff_data, dict) or 'changes' not in diff_data:
        print("Invalid diff data format.")
        return None
    
    allowed_change_types = {'add', 'edit', 'delete', 'rename', 'edit, rename'}
    
    filtered_changes = []
    for change in diff_data['changes']:
        if 'item' in change and not change['item'].get('isFolder', False):
             if change.get("changeType", "").lower() in allowed_change_types:
                  filtered_changes.append(change)
 
    diff_data['changes'] = filtered_changes
    return diff_data        

def create_comment_from_ai_response(ai_response,diff_file,threads):
    """Create a comment from the AI response."""
    try:
        ai_data = json.loads(ai_response)
        if 'line_comments' in ai_data and ai_data['line_comments']:
            for comment_obj in ai_data['line_comments']:
                line_number = comment_obj.get("line")
                comment_text = comment_obj.get("comment")
                if line_number is not None and comment_text is not None:
                    
                    for thread in threads:
                            #Check the start line and end line with line number of comment to get the right thread
                            if thread['threadContext']['filePath'] == diff_file['path'] and line_number >= thread['threadContext']['startLine'] and line_number <= thread['threadContext']['endLine']:
                                # print(f"Comment found for file {diff_file['path']} on line {line_number} with comment: {comment_text}")
                                create_azure_devops_comment(comment_text,thread['id'],line_number)
    except json.JSONDecodeError:
        print(f"Error: Invalid JSON format from Gemini: {ai_response}")
    except Exception as e:
        print(f"Error creating comment: {e}")

def create_azure_devops_comment(comment_text, thread_id, line_number):
     """Create a comment in Azure DevOps."""
     
     url = f"{AZURE_ORG_URL}/{AZURE_PROJECT}/_apis/git/repositories/{REPO_ID}/pullRequests/{PULL_REQUEST_ID}/threads/{thread_id}/comments?api-version=7.1-preview.1"
     headers = {
        'Content-Type': 'application/json',
        'Authorization': f'{get_basic_auth_string()}'
     }
     payload = {
         "parentCommentId": 0,
         "content": comment_text,
        "commentType": 1,
         "line": line_number
     }
     
     try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)
        print(f"Successfully created comment on line {line_number} in thread {thread_id} - {response.status_code}")
     except requests.exceptions.RequestException as e:
         print(f"Failed to create comment on line {line_number}: {e} - {response.status_code}")
     return response.json()

def get_file_diff_content(file_diff_url):
        """Get the diff content from a specific file."""
        headers = {
        'Authorization': f'{get_basic_auth_string()}'
        }
        try:
            response = requests.get(file_diff_url, headers=headers)
            response.raise_for_status()
            return response.text.splitlines()
        except requests.exceptions.RequestException as e:
            print(f"Error getting file diff content: {e}")
            return None

def get_all_thread():
    """Get all thread in this pull request"""
    url = f"{AZURE_ORG_URL}/{AZURE_PROJECT}/_apis/git/repositories/{REPO_ID}/pullRequests/{PULL_REQUEST_ID}/threads?api-version=7.1"
    headers = {
        'Authorization': f'{get_basic_auth_string()}'
    }
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return response.json()['value']
    except requests.exceptions.RequestException as e:
        print(f"Error getting all thread: {e}")
        return None


def process_file_diff(filtered_diff, pr_details):
    if filtered_diff is not None:
         #Get all thread in this Pull request
        # threads = get_all_thread()
        # if threads:
            ai_response = analyze_code(filtered_diff, pr_details)
            if ai_response:
                try:
                    create_review_comment(ai_response)
                    # create_comment_from_ai_response(ai_response,file_diff,threads)
                except Exception as e:
                    print("Error in create_review_comment:", e)            

def get_diff(source_branch, target_branch, output_file):
    """
    Fetches the .diff file between two branches in an Azure DevOps Git repository using a Personal Access Token (PAT).

    Args:
        repo_url: The URL of the repository.  This is the URL you use to *clone* the repository (but without  ".git" added at the end by clone). It should look like
          "https://dev.azure.com/{organization}/{project}/_git/{repositoryName}".  Don't include the .git at the end.
        source_branch: The name of the source branch (e.g., "feature/my-feature").
        target_branch: The name of the target branch (e.g., "main" or "develop").
        azure_pat: Your Azure DevOps Personal Access Token.
        output_file: The path to the file where the .diff will be saved.

    Returns:
        True if the .diff was successfully retrieved and saved, False otherwise.
        Prints an error message to the console if the request fails or an unexpected status occurs.
    """

    # Construct the API URL for getting the diff.  See:
    #   https://learn.microsoft.com/en-us/rest/api/azure/devops/git/diffs/get?view=azure-devops-rest-7.1&tabs=HTTP

    url = f"{AZURE_ORG_URL}/{AZURE_PROJECT}/_apis/git/repositories/{REPO_ID}/diffs/commits?api-version=7.1"
    # Note:  The parameters below *must* use "baseVersion", not "commonCommitTargetVersion" for the *target* branch,
    # even though you're comparing *to* that branch.  "commonCommitTargetVersion" gives a diff in the
    # *opposite* direction of what you want.  "baseVersion" gives the standard diff.
    url += f"&baseVersion={target_branch}&baseVersionType=branch"
    url += f"&targetVersion={source_branch}&targetVersionType=branch"

    headers = {
        'Authorization': f'{get_basic_auth_string()}',
        'Content-Type': 'application/json',  # Required, even for a GET request.
    }

    try:
        response = requests.get(url, headers=headers, allow_redirects=False)  # Prevent silent redirects.
        response.raise_for_status()  # Raise an exception for bad status codes (4xx or 5xx)
        
        # If successful, save the diff content to the output file
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(response.text)
        return json.loads(response.text)

    except requests.exceptions.RequestException as e:
        print(f"Error during request: {e}")
        print(f"Response status code: {response.status_code}")
        print(f"Response content:\n{response.text}") # added to show response text
        return False
    except Exception as e:
        print(f"An unexpected error occurred {e}")
        return False


def extract_base_url(file_url):
    """
    Extracts the base URL up to '/items/' from a given Azure DevOps file URL.

    Args:
        file_url (str): The full Azure DevOps file URL.

    Returns:
        str: The base URL up to '/items/', or None if the URL doesn't match the expected format.
    """
    parsed_url = urllib.parse.urlparse(file_url)
    path_parts = parsed_url.path.split('/')
    
    # Find the index of "items"
    try:
        items_index = path_parts.index("items")
    except ValueError:
        print(f"Error: 'items' not found in the URL path: {file_url}")
        return None

    base_path = "/".join(path_parts[:items_index + 1]) # include "items" in result

    base_url = urllib.parse.urlunparse(
        (parsed_url.scheme, parsed_url.netloc, base_path, "", "", "")
    )
    return base_url


def handle_edit(old_file_path,new_file_path, file_url, base_commit):
    """
    Generates a Git-style diff between two files.

    Args:
        file1_path: Path to the first file (source/original).
        file2_path: Path to the second file (target/modified).

    Returns:
        A string containing the Git-style diff, or None if an error occurs.
    """


    # Determine file names for the diff header
    file1_name = "a/" + os.path.basename(old_file_path)
    file2_name = "b/" + os.path.basename(new_file_path)

    base_url = extract_base_url(file_url)
    old_file_url = f"{base_url}{old_file_path}?versionType=Commit&version={base_commit}"
    old_file_content = get_file_diff_content(old_file_url)

    new_file_content = get_file_diff_content(file_url)
    
    if old_file_content == new_file_content:
        return ""  # No difference

    differ = difflib.unified_diff(
        old_file_content,
        new_file_content,
        fromfile=file1_name,
        tofile=file2_name,
        n=1,        
        lineterm=''  #  Important:  Avoid extra newlines at end of diff hunks.
    )

    diff_str = "\n".join(differ)
    
    # Add the "diff --git" header *only if there's a difference*:
    if diff_str.strip():  # Check if the diff is not empty after removing leading/trailing spaces
      diff_str = f"diff --git {file1_name} {file2_name}\n" + diff_str
    
    return diff_str

def handle_rename(old_path: str, new_path: str):
  """
  Handles file renames and generates the appropriate git diff output.

  Args:
      old_path: The original file path.
      new_path: The new file path.

  Returns:
    A string containing the git diff output for a rename.
  """

  diff_output = f"diff --git a/{os.path.basename(old_path)} b/{os.path.basename(new_path)}\n"
  diff_output += f"rename from {os.path.basename(old_path)}\n"
  diff_output += f"rename to {os.path.basename(new_path)}\n"
  return diff_output
  

def handle_delete(file_path, file_url, base_commit):
    """
    Handles file deletions and generates the appropriate git diff output.
    """
    base_url = extract_base_url(file_url)
    old_file_url = f"{base_url}{file_path}?versionType=Commit&version={base_commit}"
    file_content = get_file_diff_content(old_file_url)        
    
    diff_output = f"diff --git a/{os.path.basename(file_path)} b/{os.path.basename(file_path)}\n"
    diff_output += f"deleted file mode 100644\n" #  Or 100755 if executable.  Check with os.stat(file_path).st_mode

    differ = difflib.unified_diff(
        file_content,
        [],  # Empty list for deleted file
        fromfile="a/" + os.path.basename(file_path),
        tofile="/dev/null",
        n=1,
        lineterm=''
    )
    diff_output += "\n".join(differ)

    return diff_output


def handle_add(file_path, file_url):
  """
  Handles new file additions and generates the appropriate git diff output
  """

  file_content = get_file_diff_content(file_url)        

  diff_output = f"diff --git a/{os.path.basename(file_path)} b/{os.path.basename(file_path)}\n"
  diff_output += f"new file mode 100644\n"  #  Or 100755 if executable.
  differ = difflib.unified_diff(
        [],  # Empty list for added file
        file_content,
        fromfile="/dev/null",
        tofile="b/" + os.path.basename(file_path),
        n=1,
        lineterm=''
    )

  diff_output += "\n".join(differ)

  return diff_output

def process_file_changes(file_changes):
    """
    Processes a list of file changes and generates a combined Git-style diff.

    Args:
        file_changes: A dictionary containing file change information, as provided in the problem description.

    Returns:
        A string containing the combined Git-style diff for all changes.  Returns an empty string if there are no changes.
        Returns None if an error prevents processing.
    """

    combined_diff = ""
    base_commit = file_changes['baseCommit']

    for change in file_changes['changes']:
        change_type = change['changeType'].lower()
        file_path = change['item']['path']
        file_url = change['item']['url']

        if change_type == 'edit' or change_type == 'edit, rename':
            original_file_path = change.get('sourceServerItem',file_path)

            if original_file_path != file_path:
                rename_diff = handle_rename(original_file_path, file_path)
                if rename_diff is not None:
                    combined_diff += rename_diff + "\n"

            # For 'edit', we need a previous version of the file.  We'll use originalObjectId + path.
            # In a real scenario, we'd fetch the OLD content based on originalObjectId,
            # but here we simulate it by assuming a file with _old suffix exists

            diff = handle_edit(original_file_path, file_path, file_url, base_commit)
            if diff is not None:
                combined_diff += diff + "\n"

        elif change_type == 'delete':
            diff = handle_delete(file_path,file_url, base_commit)
            if diff is not None:
                combined_diff += diff + "\n"

        elif change_type == 'add':
            diff = handle_add(file_path, file_url)
            if diff is not None:
                combined_diff += diff + "\n"
        
        elif change_type == 'rename':
            original_file_path: str = change['sourceServerItem']

            diff = handle_rename(original_file_path, file_path)
            if diff is not None:
                combined_diff += diff + "\n"

        else:
            print(f"Unsupported change type: {change_type}")
            return None  # Or handle the unsupported type as appropriate

    return combined_diff.strip()  # Remove trailing newline
        
def main():
    """Main function to execute the code review."""

    pull_request_details = get_pull_request_details()
    if not pull_request_details:
        print("Failed to retrieve pull request details. Exiting.")
        return

    diff_data = get_diff(pull_request_details.source_branch, pull_request_details.target_branch, OUTPUT_FILE)
    if not diff_data or 'changes' not in diff_data:
        print("No diffs found in the pull request. Exiting.")
        return
    
    filtered_diff_data = _filter_diff_data(diff_data)

    file_diffs = filtered_diff_data['changes']
    
    if not file_diffs:
        print("No file changes to process")
        return

    # Get content changes of the file
    combined_diff_output = process_file_changes(filtered_diff_data)

    if combined_diff_output:
        # print(f"Combined Diff Output:\n{}")    
        with open('combined_diff.diff', 'w', encoding='utf-8') as f:
            f.write(combined_diff_output)

    parsed_diff = parse_diff(combined_diff_output)

    # print(f"parsed_diff: {parsed_diff}")

    exclude_patterns = (EXCLUDE_PATTERN_DEFAULT + os.environ.get("INPUT_EXCLUDE", "*.json,*.graphql")).split(",")
    exclude_patterns = [s.strip() for s in exclude_patterns]
    print(f"exclude_patterns: {exclude_patterns}")
    filtered_diff = [
        file
        for file in parsed_diff
        if not any(fnmatch.fnmatch(file.get('path', ''), pattern) for pattern in exclude_patterns)
    ]
    print(f"filtered_diff: {filtered_diff}")

    if filtered_diff:
        # print(f"Combined Diff Output:\n{}")    
        with open('filtered_diff.diff', 'w', encoding='utf-8') as f:
            for line in filtered_diff:
                f.write(f"{line},\n")
    
    process_file_diff(filtered_diff,pull_request_details)
                    
    # with ThreadPoolExecutor(max_workers=5) as executor:  # You can adjust the number of workers
    #         futures = [executor.submit(process_file_diff, file_diff,base_commit) for file_diff in file_diffs]

    #         for future in as_completed(futures):
    #             try:
    #                 future.result()  # Get result (or exception) from the completed future
    #             except Exception as e:
    #                 print(f"Error in a thread: {e}")

    print("Code review process completed.")
    
if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("Error:", error)
