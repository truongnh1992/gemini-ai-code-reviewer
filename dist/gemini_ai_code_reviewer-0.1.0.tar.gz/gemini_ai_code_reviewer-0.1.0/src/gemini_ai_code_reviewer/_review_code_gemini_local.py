import json
import os
from typing import List, Dict, Any
import google.generativeai as Client
import subprocess
import fnmatch

from models.pr_detail import PRDetails
from utils.gemini_analyze import analyze_code, summarize_review, create_review_comment
from utils.git_helper import EXCLUDE_PATTERN_DEFAULT, parse_diff

gemini_client = Client.configure(api_key='AIzaSyDWTFP37AMLZddgsY4Hf2yjyfZOh3tyV8Y')

def get_pr_details() -> PRDetails:
    """Retrieves details of the pull request from GitHub Actions event payload."""

    return PRDetails("Local Owner", "Local Repo", "", "Feat/EZRX-30710: MB: Calculate tax on small order fee", 
'''
Solution
- create `enableBalanceAmountQuery` on RemoteConfigService to manage using new field and UI or old fields
- rename amountTotal to balanceTotal to avoid confuse on naming
- Remove unused field "amountInTransactionCurrency" on customerOpenItems API
- Add new fields amount, cwtAmount, balance on customerOpenItems API, cwtAmount and balance only use for PH market
- Separate display balance for PH market and amount for other market for balanceTotal
- Change paymentAmount when we create payment from amount to balance, so it'll be balance for PH and amount for other market
- Create deductionAmount widget, only display on PH market
- Inject `enableBalanceAmountQuery` on toDomain to avoid inject directly inside entity, can delete easily.
''','feat/EZRX-30710-mb-calculate-tax-on-small-order-fee','v3')

def get_diff(target_branch="v3"): # Added target_branch argument
    """Gets the git diff between current branch and target_branch."""
    try:
        diff_process = subprocess.run(
            ["git", "diff", target_branch], capture_output=True, text=True, check=True
        )
        diff = diff_process.stdout
        print(f"Retrieved diff length: {len(diff) if diff else 0}")
        return diff

    except subprocess.CalledProcessError as e:
        print(f"Error getting diff: {e.returncode} output {e.output}")
        return ""

def main():
    """Main function to execute the code review process."""
    pr_details = get_pr_details()


    diff = get_diff()
    if not diff:
        print("There is no diff found")
        return
    if diff:
        # print(f"Combined Diff Output:\n{}")    
        with open('git_diff.diff', 'w', encoding='utf-8') as f:
            f.write(diff)
            
    parsed_diff = parse_diff(diff)

    exclude_patterns = (EXCLUDE_PATTERN_DEFAULT + os.environ.get("INPUT_EXCLUDE", "*.json,*.graphql")).split(",")
    exclude_patterns = [s.strip() for s in exclude_patterns]

    filtered_diff = [
        file
        for file in parsed_diff
        if not any(fnmatch.fnmatch(file.get('path', ''), pattern) for pattern in exclude_patterns)
    ]

    if filtered_diff:
        # print(f"Combined Diff Output:\n{}")    
        with open('filtered_diff.diff', 'w', encoding='utf-8') as f:
            for line in filtered_diff:
                f.write(f"{line},\n")            

    comments = analyze_code(filtered_diff, pr_details)
    if comments:
        try:
            create_review_comment(comments)
        except Exception as e:
            print("Error in create_review_comment:", e)
    # summarize = summarize_review(filtered_diff, pr_details)
    # if summarize:
    #     try:
    #         create_review_comment(summarize,output_file= "gemini_review_summarize.json")
    #     except Exception as e:
    #         print("Error in create_review_comment summarize:", e)

if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("Error:", error)
